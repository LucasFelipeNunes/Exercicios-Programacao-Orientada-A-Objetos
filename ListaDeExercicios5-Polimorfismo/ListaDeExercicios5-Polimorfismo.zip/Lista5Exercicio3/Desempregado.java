public class Desempregado extends Candidato{
	private int mesesSemTrabalhar;
	
	public Desempregado(){
		super();
	}
	
	public void setMesesSemTrabalhar(int mesesSemTrabalhar){
		this.mesesSemTrabalhar = mesesSemTrabalhar;
	}
	
	public int getMesesSemTrabalhar(){
		return mesesSemTrabalhar;
	}
}
