public class Estagio extends Vaga{
	private int meses;
	
	public Estagio(){
		super();
	}
	
	public void setMeses(int meses){
		this.meses = meses;
	}
	
	public int getMeses(){
		return meses;
	}
}
